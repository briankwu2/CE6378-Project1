#!/bin/bash
# Script to compile the client/server java files
javac ListeningThread.java ClientThread.java ServerClass.java ProcessNode.java
javac DriverPart1.java 
echo Done Compiling!

